export const outputDir = 'dist';
